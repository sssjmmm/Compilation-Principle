message_text_success_style = \
    "QPlainTextEdit {\n" \
    "color: #00ab9d\n" \
    "}\n"

message_text_error_style = \
    "QPlainTextEdit {\n" \
    "color: rgb(192, 0, 0)\n" \
    "}\n"

message_label_success_style = \
    "QLabel {\n" \
    "color: #00ab9d\n" \
    "}\n"

message_label_error_style = \
    "QLabel {\n" \
    "color: rgb(192, 0, 0)\n" \
    "}\n"